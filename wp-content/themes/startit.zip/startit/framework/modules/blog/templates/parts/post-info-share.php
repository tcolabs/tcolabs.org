<div class ="qodef-blog-share">
	<?php echo qode_startit_get_social_share_html(); ?>
</div>