<?php

require_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/fullwidth-slider/fullwidth-slider-holder.php';
require_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/fullwidth-slider/fullwidth-slider-item.php';