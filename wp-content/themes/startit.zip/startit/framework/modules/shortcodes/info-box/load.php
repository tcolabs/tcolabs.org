<?php

include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/info-box/info-box.php';
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/info-box/custom-styles/info-box.php';