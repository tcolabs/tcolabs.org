<?php

include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/piecharts/piechartbasic/pie-chart-basic.php';
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/piecharts/piechartbasic/custom-styles/pie-chart-basic.php';