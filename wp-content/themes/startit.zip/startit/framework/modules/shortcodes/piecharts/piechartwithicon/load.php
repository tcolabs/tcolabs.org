<?php

include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/piecharts/piechartwithicon/pie-chart-with-icon.php';
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/piecharts/piechartwithicon/custom-styles/pie-chart-with-icon.php';