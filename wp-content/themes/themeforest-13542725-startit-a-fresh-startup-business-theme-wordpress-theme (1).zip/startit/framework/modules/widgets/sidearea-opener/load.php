<?php

require_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/widgets/sidearea-opener/side-area-opener.php';