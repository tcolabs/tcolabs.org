<div class="qodef-portfolio-info-item">
    <h2><?php the_title(); ?></h2>
    <div class="qodef-portfolio-content">
        <?php the_content(); ?>
    </div>
</div>