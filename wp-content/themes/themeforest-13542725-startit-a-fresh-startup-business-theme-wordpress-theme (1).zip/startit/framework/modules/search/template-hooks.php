<?php

//Get search HTML
add_action('qode_startit_before_page_header', 'qode_startit_get_search', 9);