<?php

include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/image-with-icon/image-with-icon.php';