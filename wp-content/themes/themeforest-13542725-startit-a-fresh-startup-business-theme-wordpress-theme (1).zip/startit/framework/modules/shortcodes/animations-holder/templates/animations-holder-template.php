<div <?php qode_startit_class_attribute($class); ?> <?php echo qode_startit_get_inline_attrs($data); ?>>
	<div <?php qode_startit_inline_style($style); ?>>
		<?php echo do_shortcode($content); ?>
	</div>

</div>