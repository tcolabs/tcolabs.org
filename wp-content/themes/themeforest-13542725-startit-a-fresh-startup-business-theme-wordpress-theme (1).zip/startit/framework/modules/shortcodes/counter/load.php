<?php

include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/counter/counter.php';
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/counter/custom-styles/counter.php';