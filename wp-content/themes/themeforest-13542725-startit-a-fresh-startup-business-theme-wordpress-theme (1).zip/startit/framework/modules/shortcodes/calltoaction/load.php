<?php

include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/calltoaction/call-to-action.php';
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/calltoaction/custom-styles/call-to-action.php';